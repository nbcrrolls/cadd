/***************************************************************************
 *cr                                                                       
 *cr            (C) Copyright 1995-2011 The Board of Trustees of the           
 *cr                        University of Illinois                       
 *cr                         All Rights Reserved                        
 *cr                                                                   
 ***************************************************************************/

/***************************************************************************
 * RCS INFORMATION:
 *
 *	$RCSfile: PhoneTracker.C,v $
 *	$Author: johns $	$Locker:  $		$State: Exp $
 *	$Revision: 1.2 $	$Date: 2010/12/16 04:08:34 $
 *
 ***************************************************************************
 * DESCRIPTION:
 *   Listen for UDP packets from WiFi smartphones
 *
 ***************************************************************************/
#if defined(VMDPHONETRACKER)

#include <stdlib.h> // for getenv(), abs() etc.
#include <string.h>
#include <math.h>
#include "VMDApp.h"
#include "PhoneTracker.h"
#include "Matrix4.h"
#include "Inform.h"
#include "utilities.h"

/* socket stuff */
#include <stdio.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/socket.h>
#include <time.h>
#include <netinet/in.h>

/* Only works with aligned 4-byte quantities, will cause a bus error */
/* on some platforms if used on unaligned data.                      */
static void swap4_aligned(void *v, long ndata) {
  int *data = (int *) v;
  long i;
  int *N;
  for (i=0; i<ndata; i++) {
    N = data + i;
    *N=(((*N>>24)&0xff) | ((*N&0xff)<<24) |
        ((*N>>8)&0xff00) | ((*N&0xff00)<<8));
  }
}

typedef struct {
  /* socket management data */
  char buffer[1024];
  struct sockaddr_in sockaddr;
  int sockfd;
  int fromlen;

  /* phone state vector */
  int seqnum;
  int buttons;
  float rx;
  float ry;
  float rz;
  float tx;
  float ty;
  float tz;
  float rotmatrix[9];
} phonehandle;



void * phone_listener_create(int port) {
  phonehandle *ph = (phonehandle *) calloc(1, sizeof(phonehandle));
  if (ph == NULL) 
    return NULL;
 
  if ((ph->sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    perror("socket: ");
    free(ph);
    return NULL;
  }

#if 1
  /* make socket non-blocking */
  int sockflags;
  sockflags = fcntl(ph->sockfd, F_GETFL, 0);
  fcntl(ph->sockfd, F_SETFL, sockflags | O_NONBLOCK);
#endif

  memset(&ph->sockaddr, 0, sizeof(ph->sockaddr));
  ph->sockaddr.sin_family      = AF_INET;
  ph->sockaddr.sin_addr.s_addr = htonl(INADDR_ANY);
  ph->sockaddr.sin_port        = htons(port);

  if (bind(ph->sockfd, (struct sockaddr *)&ph->sockaddr, sizeof(sockaddr)) < 0) {
    perror("bind: ");
    free(ph);
    return NULL;
  }

  return ph;
}

int phone_listener_poll(void *voidhandle, 
                        float &tx, float &ty, float &tz,
                        float &rx, float &ry, float &rz,
                        int &buttons) {
  phonehandle *ph = (phonehandle *) voidhandle;
 
  memset(ph->buffer, 0, sizeof(ph->buffer));
  socklen_t fromlen=0;
  int packlen=0;

  packlen=recvfrom(ph->sockfd, ph->buffer, sizeof(ph->buffer), 0, (struct sockaddr *)&ph->sockaddr, &fromlen);
  /* no packets read */
  if (packlen < 1) {
// printf("no phone packet..\n");
    return 0;
  }

  /* we now have info.  Decode it */
  if (((int*)ph->buffer)[0] != 1) {
    swap4_aligned(ph->buffer, sizeof(ph->buffer) / 4);
  }
  if (((int*)ph->buffer)[0] != 1) {
    printf("Received unrecognized phone packet...\n");
    return 0;
  }

  int endianism  = ((int*)ph->buffer)[0];     /* endianism.  Should be 1  */
  int apiversion = ((int*)ph->buffer)[1];     /* API version */
  int packtype   = ((int*)ph->buffer)[2];     /* payload description */
  ph->buttons    = ((int*)ph->buffer)[3];     /* button state */
  ph->seqnum     = ((int*)ph->buffer)[4];     /* sequence number */
  ph->rx         = ((float*)ph->buffer)[6];   /* orientation 1 */
  ph->ry         = ((float*)ph->buffer)[7];   /* orientation 2 */
  ph->rz         = ((float*)ph->buffer)[5];   /* orientation 0 */
  ph->tx         = ((float*)ph->buffer)[8];   /* accel 0 */
  ph->ty         = ((float*)ph->buffer)[9];   /* accel 1 */
  ph->tz         = ((float*)ph->buffer)[10];  /* accel 2 */
  int i;
  for (i=0; i<9; i++) 
    ph->rotmatrix[i] = ((float*)ph->buffer)[11];

#if 0
  // convert radians to degrees for debugging
  ph->rx *= 180 / VMD_PI;
  ph->ry *= 180 / VMD_PI;
  ph->rz *= 180 / VMD_PI;
#endif

  printf("phone) end:%d ver:%d desc:%d seq:%d buttons:%08x " 
         "O:%6.2f %6.2f %6.2f A:%6.2f %6.2f %6.2f\n",
         endianism, apiversion, packtype, ph->seqnum,
         ph->buttons, ph->rx, ph->ry, ph->rz, ph->tx, ph->ty, ph->tz);

  // Android angle data:
  // values[0]: Azimuth, rotation around the Z axis (0<=azimuth<360). 
  //            0 = North, 90 = East, 180 = South, 270 = West
  // values[1]: Pitch, rotation around X axis (-180<=pitch<=180), 
  //            with positive values when the z-axis moves toward the y-axis.
  // values[2]: Roll, rotation around Y axis (-90<=roll<=90), 
  //            with positive values when the z-axis moves toward the x-axis.
  buttons = ph->buttons;

  rx = -ph->rx;
  ry = -(ph->rz-180); // Renormalize Android X angle from 0:360deg to -180:180
  rz =  ph->ry; 
  tx = 0.0;
  ty = 0.0;
  tz = 0.0;

#if 1
  // get absolute values of axis forces for use in
  // null region processing and min/max comparison tests
  float t_null_region = 0.01;
  float r_null_region = 10.0;
  float atx = fabs(tx);
  float aty = fabs(ty);
  float atz = fabs(tz);
  float arx = fabs(rx);
  float ary = fabs(ry);
  float arz = fabs(rz);

  // perform null region processing
  if (atx > t_null_region) {
    tx = ((tx > 0) ? (tx - t_null_region) : (tx + t_null_region));
  } else {
    tx = 0;
  }
  if (aty > t_null_region) {
    ty = ((ty > 0) ? (ty - t_null_region) : (ty + t_null_region));
  } else {
    ty = 0;
  }
  if (atz > t_null_region) {
    tz = ((tz > 0) ? (tz - t_null_region) : (tz + t_null_region));
  } else {
    tz = 0;
  }
  if (arx > r_null_region) {
    rx = ((rx > 0) ? (rx - r_null_region) : (rx + r_null_region));
  } else {
    rx = 0;
  }
  if (ary > r_null_region) {
    ry = ((ry > 0) ? (ry - r_null_region) : (ry + r_null_region));
  } else {
    ry = 0;
  }
  if (arz > r_null_region) {
    rz = ((rz > 0) ? (rz - r_null_region) : (rz + r_null_region));
  } else {
    rz = 0;
  }
#endif

  printf("vmd) O:%6.2f %6.2f %6.2f A:%6.2f %6.2f %6.2f\n",
         rx, ry, rz, tx, ty, tz);

  return 1; 
}

int phone_listener_destroy(void *voidhandle) {
  phonehandle *ph = (phonehandle *) voidhandle;
  close(ph->sockfd); /* close the socket */ 
  free(ph);
  return 0;
}

PhoneTracker::PhoneTracker(VMDApp *vmdapp) {
  app = vmdapp; // copy VMDApp pointer for use in accessing local spaceball
  phone=NULL;   // zero it out to begin with
}

int PhoneTracker::do_start(const SensorConfig *config) {
  if (phone) return FALSE;
  if (!config->require_local()) return 0;
  if (!config->have_one_sensor()) return 0;

  char *myUSL = stringdup(config->getname());

printf("Phone USL: '%s'\n", myUSL);
  
  phone = phone_listener_create(3141);
  if (phone == NULL) 
    msgErr << "Failed to open Phone port, tracker disabled" << sendmsg; 

  // set the default translation and rotation increments
  // these really need to be made user modifiable at runtime
  transInc = 1.0f;
    rotInc = 0.01f;
  scaleInc = 1.0f;

  // reset the position
  moveto(0,0,0);
  orient->identity();

  delete [] myUSL;

  return TRUE;
}

PhoneTracker::~PhoneTracker(void) {
  if (phone != NULL)
    phone_listener_destroy(phone);
}

void PhoneTracker::update() {
  Matrix4 temp;

  if(!alive()) {
    moveto(0,0,0);
    orient->identity();
    return;
  }

  if (phone != NULL ) {
    float tx, ty, tz, rx, ry, rz;
    tx=ty=tz=rx=ry=rz=0.0f;
    int buttons=0;

    if (phone != NULL ) {
// printf("polling phone socket..\n");
      if (phone_listener_poll(phone, tx, ty, tz, rx, ry, rz, buttons)) {
        temp.identity();
        temp.rot( ((float)rx)*rotInc, 'x' );
        temp.rot( ((float)ry)*rotInc, 'y' );
        temp.rot( ((float)rz)*rotInc, 'z' );
        temp.multmatrix(*orient);
        orient->loadmatrix(temp);
        pos[0] += tx * transInc;
        pos[1] += ty * transInc;
        pos[2] +=-tz * transInc;
      }
    }
  }
}

#endif
